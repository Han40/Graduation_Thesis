clc; clear all;close all;
tic;
str={'case300'};
for i=1:length(str)
mpc=eval(str{i});
N=length(mpc.bus);
L=length(mpc.branch);

ht1=java.util.Hashtable;
for k=1:N
    ht1.put(mpc.bus(k,1),k);
end
Bus2Num=@(x)ht1.get(x);

mpc.bus(:,1)=arrayfun(Bus2Num,mpc.bus(:,1));
mpc.branch(:,1)=arrayfun(Bus2Num,mpc.branch(:,1));
mpc.branch(:,2)=arrayfun(Bus2Num,mpc.branch(:,2));
mpc.gen(:,1)=arrayfun(Bus2Num,mpc.gen(:,1));


slack0=find(mpc.bus(:,2)==3);
baseMVA=mpc.baseMVA;
busData=mpc.bus;           % Bus info
branchData=mpc.branch;     % Branch info

[BbusSparse,~,~,~] = MakeBdc(baseMVA, busData, branchData); % Obtain sparse admittance matrix
%% ��һ�б�ʾ���ڵ���
Bdc0=[(1:N)' full(BbusSparse)];                                       % Full admittance matrix
Branch0=[(1:L)' mpc.branch(:,[1 2 4])];
Branch0(:,4)=1./Branch0(:,4);

Net0=struct('Bdc',{Bdc0},'Branch',{Branch0});
[powerInj, ~, ~]=MakePowerInjVector(mpc,busData,slack0);
Power0=[(1:N)' powerInj/baseMVA];

ht2=java.util.Hashtable;
for k=1:L
    key=sort(Branch0(k,[2 3]))*[200;1];
    ht2.put(key,k);
end
node2edge=@(x)ht2.get(x);

eval(['save ',str{i},'.mat Net0 node2edge Power0 slack0']);
end