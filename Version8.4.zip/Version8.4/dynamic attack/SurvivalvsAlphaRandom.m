TestMax=1;
M=100;
Alpha=linspace(1,2,M);
removalStrategy=1;
alpha=1.1;
A = zeros(M,2);
Mpc=case118;
for i = 1 : TestMax,
    [LS, CS, DS] = GetEffectOfAlphaOnCascDamage(Mpc, removalStrategy, Alpha);
    B = [LS DS];
    A = A + B;
end
SurvivalvsAlpha(Alpha,A/TestMax,'case118-Random Remove');



% [flowStageResult] = SimCascFailures(Mpc, alpha, removalStrategy);
% [ powerSatisfiedPerStage, powerLossPerStage ] = GetPowerLossPerStage(flowStageResult);
% SurvivalvsAlpha([powerSatisfiedPerStage;powerLossPerStage ]','case118-BC Remove');
