function  sys= depart(ExpandMat)
N=size(ExpandMat,1);
NoNode=ExpandMat(:,1);
AdjReduced=full(ExpandMat(:,2:end));
AdjReduced(eye(N)==1)=1;


sys=cell(0);
flag=zeros(1,size(AdjReduced,1));
k=0;%k��sys�ĳ��ȣ�
Q=zeros(1,0);
for i=1:length(AdjReduced)
    if flag(i)==0%δ����ѯ��
        k=k+1;
        flag(i)=1;
        Q(1)=i;
        sys{k}=i;
    end
        while(~isempty(Q))
              u=Q(1);
              Q(1)=[];
              v=find(AdjReduced(u,:)~=0);
              for j=1:length(v)%v���Ӵ�u�Ǹ���
                  if flag(v(j))==0
                      flag(v(j))=1;
                      sys{k}=cat(2,sys{k},NoNode(v(j)));
                      Q=cat(2,Q,v(j));
                  end
              end
        end
end


