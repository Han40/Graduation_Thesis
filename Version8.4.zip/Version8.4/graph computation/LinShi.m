% clc; clear all;close all;
% tic;
% % %% ���ݳ�ʼ��
% global Power0; 
% global slack0;
% global N;
% global L;
% global Net0;
% global node2edge;
% load case118.mat;
% N=size(Power0,1);
% L=size(Net0.Branch,1);
% Efficiency0=getNetEfficiency(Net0);
% NetAbi0=getNetAbility(Net0);
% 
% Pline0=chaoliu(Net0);
% Pmax=abs(Pline0*2);
% s0=getNodeBet(Net0); 
% InitalP=sum(abs(Pline0)./Pmax);
% % ɾ��һ����·������Ӱ�� 
% Value=zeros(L,3);
% for line=1:L
%     CurNet=Net0;
%     
%     
%     CurNet=damage(1,CurNet,line); 
%     sss=getNodeBet(CurNet); 
%     Value(line,1)=getNetEfficiency(CurNet);  
%     Value(line,2)=getNetAbility(CurNet);
%     
%     Pline=chaoliu(CurNet);
%     
%     
%     Value(line,3)=sum(abs(Pline)./Pmax);
% end
% % ��ͼ
% X=1:L;
% inital=[Efficiency0 NetAbi0 InitalP];
% COM=repmat(inital,L,1);
% Y=(COM-Value)*diag(1./inital)*100;
% Y(:,3)=-Y(:,3);
% figure(1);
% subplot(3,1,1);
% plot(X',Y(:,1));
% subplot(3,1,2);
% plot(X',Y(:,3));
% subplot(3,1,3);
% plot(X',Y(:,2));
% 
% % ��ͳ�Ʋ���
% STD=std(Y,0,1)
% c1=corrcoef(Y(:,1),Y(:,2))
% c2=corrcoef(Y(:,2),Y(:,3))
% 
% 





clc;clear all;close all;
load CascData33.mat;
len=20;
Alpha=linspace(0,1,20);
Data1=[1-ATK(1).NetAbi(11,:);1-ATK(2).NetAbi(11,:);1-ATK(3).NetAbi(11,:)]';
createfigure33(Alpha,Data1*100)

% CreateCascFigure([Alpha' (1-Data1)*100],...
%     {'���紫�������½�����(%)','lower',max(Alpha)});
% CreateCascFigure([Alpha' (1-Data2)*100],...
%     {'���紫�������½�����(%)','higher',max(Alpha)});

% CreateCascFigure([Alpha' (1-ATK(1).NetAbi)*100],...
%     {'���紫�������½�����(%)','RN',max(Alpha)});
% CreateCascFigure([Alpha' (1-ATK(1).NetAbi)*100],...
%     {'���紫�������½�����(%)','HLN',max(Alpha)});
% plot(Alpha',(1-ATK(3).NetAbi)*100);








